#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <locale.h>

struct Tconsulta
{
    int cod;
    char nome_paciente [50];
    char nome_medico [50];
    char horario_consulta [10];
    char data_consulta [10];

};
struct Tmedico
{
    int cod;
    char nome [50];
    char celular [9];
    char especialidade [50];

};
struct Tpaciente
{
    int cod;
    char nome [50];
    char endereco [50];
    char celular [9];
    char data_nascimento [10];
    char plano_saude[50];

};

typedef struct Tconsulta consulta;
typedef struct Tmedico medico;
typedef struct Tpaciente paciente;

int main()
{
 FILE *f;
 char op;
 setlocale(LC_ALL,"portuguese");
 if((f = fopen("Cadastros.txt", "r+b"))==NULL) // arquivo existe
 { printf("Arquivo n�o exista ... criando arquivo!");
 if((f = fopen("Cadastros.txt", "w+b"))==NULL) //arq n�o existe
 { printf("Erro na cria��o do arquivo!!");
 exit(1);
 }
 system("pause");
 }

do
 { printf("Escolha:\n");
 printf("a-incluir cadastro m�dico\n");
 printf("b-incluir cadastro paciente\n");
 printf("c-incluir cadastro consulta\n");
 printf("d-localizar consulta por nome do paciente\n");
 printf("e-localizar consulta por nome do m�dico\n");
 printf("g-localizar consulta por data\n");
 printf("h-sair do sistema\n");
 op=getch();
 switch (op)
 {
 case 'a':
 printf("Inclus�o de m�dico...\n");
 cadastromedico(f);
 break;
 case 'b':
 printf("Inclus�o de paciente...\n");
 cadastropaciente(f);
 break;
 case 'c':
 printf("Inclus�o de cadastro...\n");
 cadastroconsulta(f);
 break;
 case 'd':
 printf("Localiza��o consulta por nome do paciente ...\n");
 localizaconsultanomepad(f);
 break;
 case 'e':
 printf("Localiza��o consulta por nome do medico ...\n");
 localizaconsultanomemed(f);
 system("pause");
 break;
 case 'b':
 printf("Localiza��o consulta por data ...\n");
 localizaconsultadata(f);
 break;
 }
 }
 while (op!='h');
 fclose(f);
 return 0;


 cadastromedico(fopen("db.bin", "ab+"));
 cadastropaciente(fopen("db.bin", "ab+"));
 cadastroconsulta(fopen("db.bin", "ab+"));
}

/* Cadastrar o Medico */
void cadastromedico(FILE *fl)
{
    paciente med;
    int posicao, codigo;
    printf("Digite o codigo: ");
    fflush(stdin);
    scanf("%d",&med.cod);
    posicao=localizacodigomedico(fl,med.cod);
    if(posicao==-1){
        printf("Digite o seu nome completo: ");
        fflush(stdin);
        gets(med.nome);

        printf("Digite o seu celular: ");
        fflush(stdin);
        gets(med.celular);

        printf("Digite sua especializa��o: ");
        fflush(stdin);
        gets(med.especialidade);


        fseek(fl,0,SEEK_SET);
        fwrite(&med, sizeof(med),1,fl);
        fclose(fl);
    }
    else {
        printf("Medico j� est� cadastrado no sistema. Por isso n�o foi incluido.\n");
    }
}

/* Cadastrar o Paciente */
void cadastropaciente(FILE *fl)
{
    paciente pac;
    int posicao, codigo;
    printf("Digite o codigo: ");
    fflush(stdin);
    scanf("%d",&pac.cod);
    posicao=localizacodigopaciente(fl,pac.cod);
    if(posicao==-1){
        printf("Digite o seu nome completo: ");
        fflush(stdin);
        gets(pac.nome);

        printf("Digite o seu endere�o: ");
        fflush(stdin);
        gets(pac.endereco);

        printf("Digite o seu celular: ");
        fflush(stdin);
        gets(pac.celular);

        printf("Digite a data do seu nascimento: ");
        fflush(stdin);
        gets(pac.data_nascimento);

        printf("Digite o seu plano de sa�de: ");
        fflush(stdin);
        gets(pac.plano_saude);


        fseek(fl,0,SEEK_SET);
        fwrite(&pac, sizeof(pac),1,fl);
        fclose(fl);
    }
    else {
        printf("Paciente j� est� cadastrado no sistema. Por isso n�o foi incluido.\n");
    }
}

/* Cadastrar a Consulta */
void cadastroconsulta(FILE *fl)
{
    consulta cont;
    int posicao, codigo;
    printf("Digite o codigo: ");
    fflush(stdin);
    scanf("%d",&cont.cod);
    posicao=localizacodigomed(fl,cont.cod);
    if(posicao==-1){
        printf("Digite o nome do paciente: ");
        fflush(stdin);
        gets(cont.nome_paciente);

        printf("Digite o nome do medico: ");
        fflush(stdin);
        gets(cont.nome_medico);

        printf("Digite a data da consulta: ");
        fflush(stdin);
        gets(cont.data_consulta);

        printf("Digite o horario da consulta: ");
        fflush(stdin);
        gets(cont.horario_consulta);

        printf("Cadastro completo!\n");
        fseek(fl,0,SEEK_SET);
        fwrite(&cont, sizeof(cont),1,fl);
        fclose(fl);
    }
    else {
        printf("Paciente ou Medico j� est� cadastrado no sistema. Por isso n�o foi incluido.\n");
    }
}
/* Localizar o c�digo do Paciente */
  int localizacodigopaciente(FILE *fl, int cod) {
    int posicao=-1,achou=0;
    paciente pac;
    fseek(fl,0,SEEK_SET);
    fread(&pac, sizeof(pac),1, fl);
    while (!feof(fl) && !achou)
    {
        posicao++;
        if (pac.cod == cod)
        {
            achou=1;
        }
        fread(&pac, sizeof(pac), 1, fl);
    }
    if (achou)
    {
        return posicao;
    }
    else
    {
        return -1;
    }
}

/* Localizar o c�digo do Medico */
 int localizacodigomedico(FILE *fl, int cod) {
    int posicao=-1,achou=0;
    medico med;
    fseek(fl,0,SEEK_SET);
    fread(&med, sizeof(med),1, fl);
    while (!feof(fl) && !achou)
    {
        posicao++;
        if (med.cod == cod)
        {
            achou=1;
        }
        fread(&med, sizeof(med), 1, fl);
    }
    if (achou)
    {
        return posicao;
    }
    else
    {
        return -1;
    }
}

int localizaconsultanomepad(FILE *fl){
int nome;
int posicao=-1,achou=0;
paciente pac;
consulta cont;
fseek(fl,0,SEEK_SET);
fread(&pac, sizeof(pac),1, fl);
printf("Digite o nome do paciente:\n");
scanf("%d",%nome);
while (!feof(fl) && !achou)
    {
        posicao++;
        if (pac.nome == nome && cont.nome == nome)
        {
            printf("Nome do paciente: %c\n",pac.nome);
            printf("Nome do medico: %c\n",cont.nome_medico);
            printf("Hora da consulta: %c\n",cont.horario_consulta);
            printf("Data da consulta: %c\n",cont.data_consulta);
            achou=1;

        }
        fread(&med, sizeof(med), 1, fl);
    }
    if (achou)
    {
        return posicao;
    }
    else
    {
        printf("Consultas n�o localizadas");
        return -1;
    }
}

int localizaconsultanomemed(FILE *fl){
int nome;
int posicao=-1,achou=0;
medico med;
consulta cont;
fseek(fl,0,SEEK_SET);
fread(&pac, sizeof(pac),1, fl);
printf("Digite o nome do medico:\n");
scanf("%d",%nome);
while (!feof(fl) && !achou)
    {
        posicao++;
        if (med.nome == nome && cont.nome_medico == nome)
        {
            printf("Nome do medico: %c\n",med.nome);
            printf("Nome do paciente: %c\n",cont.nome_paciente);
            printf("Hora da consulta: %c\n",cont.horario_consulta);
            printf("Data da consulta: %c\n",cont.data_consulta);

            achou=1;

        }
        fread(&med, sizeof(med), 1, fl);
    }
    if (achou)
    {
        return posicao;
    }
    else
    {
        printf("Consultas n�o localizadas");
        return -1;
    }
}

int localizaconsultadata(FILE *fl){
int data;
int posicao=-1,achou=0;
consulta cont;
fseek(fl,0,SEEK_SET);
fread(&pac, sizeof(pac),1, fl);
printf("Digite a data:\n");
scanf("%d",%data);
while (!feof(fl) && !achou)
    {
        posicao++;
        if (cont.data_consulta == data)
        {
            printf("Data da consulta: %c\n",cont.data_consulta);
            printf("Nome do paciente: %c\n",cont.nome_paciente);
            printf("Hora do medico: %c\n",cont.nome_medico);
            printf("Horario da consulta: %c\n",cont.horario_consulta);
            achou=1;

        }
        fread(&med, sizeof(med), 1, fl);
    }
    if (achou)
    {
        return posicao;
    }
    else
    {
        printf("Consultas n�o localizadas");
        return -1;
    }
}


